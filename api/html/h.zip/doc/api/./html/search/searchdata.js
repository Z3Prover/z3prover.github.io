var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvwxz~",
  1: "abcdefghilmopqrstuvz",
  2: "cmz",
  3: "abcdefgilmopqrstuvwz",
  4: "_abcdefghiklmnopqrstuvwxz~",
  5: "abcdefgiklmnoprstuvz",
  6: "aefsz",
  7: "crsz",
  8: "rsuz",
  9: "abcdefghiklmnoprstuvw",
  10: "abcdefimnoprstwx",
  11: "_mz",
  12: "c",
  13: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "properties",
  10: "related",
  11: "defines",
  12: "groups",
  13: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Properties",
  10: "Friends",
  11: "Macros",
  12: "Modules",
  13: "Pages"
};

