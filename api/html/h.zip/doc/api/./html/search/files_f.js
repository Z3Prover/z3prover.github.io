var searchData=
[
  ['tactic_2ecs',['Tactic.cs',['../_tactic_8cs.html',1,'']]],
  ['tactic_2ejava',['Tactic.java',['../_tactic_8java.html',1,'']]],
  ['tacticdecrefqueue_2ejava',['TacticDecRefQueue.java',['../_tactic_dec_ref_queue_8java.html',1,'']]],
  ['tuplesort_2ecs',['TupleSort.cs',['../_tuple_sort_8cs.html',1,'']]],
  ['tuplesort_2ejava',['TupleSort.java',['../_tuple_sort_8java.html',1,'']]]
];
