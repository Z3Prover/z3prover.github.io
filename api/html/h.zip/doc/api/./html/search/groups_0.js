var searchData=
[
  ['c_20api',['C API',['../group__capi.html',1,'']]],
  ['c_2b_2b_20api',['C++ API',['../group__cppapi.html',1,'']]]
];
