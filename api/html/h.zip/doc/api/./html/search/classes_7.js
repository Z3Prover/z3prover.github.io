var searchData=
[
  ['handle',['Handle',['../class_microsoft_1_1_z3_1_1_optimize_1_1_handle.html',1,'Optimize.Handle'],['../classz3_1_1optimize_1_1handle.html',1,'optimize::handle']]]
];
