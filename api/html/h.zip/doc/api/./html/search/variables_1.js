var searchData=
[
  ['backtrack_5flevel',['backtrack_level',['../classz3py_1_1_solver.html#a1fef634c9cff7987ae0648a43f5f439e',1,'z3py::Solver']]],
  ['bases',['bases',['../classz3py_1_1_prop_closures.html#aee3fa4bf0a9b1a18223607f2a7daaba2',1,'z3py::PropClosures']]]
];
