var searchData=
[
  ['version',['Version',['../classcom_1_1microsoft_1_1z3_1_1_version.html',1,'com::microsoft::z3']]]
];
