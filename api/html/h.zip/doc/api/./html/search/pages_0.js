var searchData=
[
  ['an_20efficient_20theorem_20prover',['An Efficient Theorem Prover',['../index.html',1,'']]]
];
